# PLAN — one thread, modulated phases

Language: **Rust**. Reasons, in the open: single static binary on Windows
with no runtime to install; BLAKE3 and rayon give multi-core hashing at I/O
speed; crossterm gives raw-mode menus and Windows virtual-terminal colour
without a widget framework. Python with `rich` was the alternative; it loses
on cold-start time for "fast and punchy" commands and on hashing throughput
for large trees. Effort was not a factor either way — both were built from
scratch here.

Every phase ends with the agent running the binary in its own runtime on a
generated fixture tree and recording what it observed. Nothing is marked
done on the strength of compiling.

## Phase 1 — exact duplicates, full command surface   ← delivered 2026-11-05

- Grammar and pre-parser (`-dr`, `.` as all, order-independent tokens)
- Walker with kind filters, hard-link collapse, `_milked` exclusion
- Size → sample → BLAKE3 pipeline, parallel hashing
- Keeper policy
- `find`, `milk`, `purge` (exact tier + byte verification + Recycle Bin),
  `--dry-run`, `--quick-search`, `--undo`, `doctor`, `--help`
- Journal (write on change only; undo for moves and bin restores)
- Renderer: theme, width fitting, in-place progress, result layouts
- Interactive menu: five workflows, four steps, confirm-with-command
- Tests: grammar, size/sample/hash staging, keeper ordering, journal
  round-trip, path shortening; end-to-end runs on a fixture tree

## Phase 2 — near-duplicate images   ← delivered 2026-11-05

- `perceptual.rs`: decode with EXIF orientation, 288×288 luminance grid,
  dHash and pHash from the mathematics in RESEARCH §2, eight dihedral
  variants per image, quality gate
- `hamming.rs`: parallel linear scan and Multi-Index Hashing, tested to
  agree; crossover measured (4,000)
- `near.rs`: union–find grouping over exact keepers and singletons;
  near keeper policy
- `img` token switches the pass on for `find`/`milk`; `purge` runs it
  always; exact-only runs print the `img` form as a `near` line
- `tests/corpus.rs`: 150 generated photographs × 21 perturbations; the
  shipped thresholds (dHash ≤10 ∧ pHash ≤14) measured at 0 false
  positives in 480,525 negative pairs — table in VERIFICATION.md
- Phase 2b (next): PDQ, 256-bit with quality gating, as `purge`'s near
  tier; measured on the same corpus before it ships

## Phase 3 — near-duplicate video

- `ffmpeg`/`ffprobe` subprocess probing and positional frame extraction
- Tier 1 positional frame hashing; tier 2 TMK-style descriptor
- `vid` token switches it on; `doctor` reports the ffmpeg state

## Phase 4 — optional deep tier

- SSCD-class descriptor behind an opt-in flag, off by default; separate
  model download; never required for the core commands

## Standing rules

- No cache, index or lock file is ever written on a scan.
- A change writes exactly one journal; `--undo` consumes it.
- Thresholds ship only after they are measured on a corpus in the phase
  that introduces them.
- New flags need a reason stronger than convenience; the menu stays at five
  choices per screen.
