//! End-to-end: the built binary on a generated fixture tree.
//!
//! Runs `find`, `milk`, `--undo`, `purge --dry-run` and the error paths,
//! and checks the tree after each step. The real `purge` + `--undo` through
//! the OS bin is `#[ignore]`d so an ordinary `cargo test` never touches the
//! machine's Recycle Bin; run it with `cargo test -- --ignored`.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

fn bin() -> PathBuf {
    PathBuf::from(env!("CARGO_BIN_EXE_dedupe"))
}

fn put(root: &Path, rel: &str, bytes: &[u8]) {
    put_at(root, rel, bytes, 1_622_505_600); // 2021-06-01
}

fn put_at(root: &Path, rel: &str, bytes: &[u8], mtime_unix: u64) {
    let p = root.join(rel);
    fs::create_dir_all(p.parent().unwrap()).unwrap();
    fs::write(&p, bytes).unwrap();
    let f = fs::File::options().write(true).open(&p).unwrap();
    f.set_modified(std::time::UNIX_EPOCH + std::time::Duration::from_secs(mtime_unix))
        .unwrap();
}

fn blob(seed: u8, len: usize) -> Vec<u8> {
    (0..len)
        .map(|i| ((i as u64 * 2_654_435_761u64) >> 7) as u8 ^ seed)
        .collect()
}

struct Fx {
    _tmp: tempfile::TempDir,
    root: PathBuf,
    journal: PathBuf,
}

fn fixture() -> Fx {
    let tmp = tempfile::tempdir().unwrap();
    let root = tmp.path().join("fx");
    let journal = tmp.path().join("journal");
    fs::create_dir_all(&root).unwrap();
    let img = blob(1, 300 * 1024);
    put_at(&root, "2019/trip/IMG_0041.jpg", &img, 1_560_297_600); // 2019-06-12, the original
    put(&root, "backup/IMG_0041.jpg", &img);
    put(&root, "backup/old/IMG_0041 (1).jpg", &img);
    let vid = blob(2, 2 * 1024 * 1024 + 777);
    put(&root, "clips/a.mp4", &vid);
    put(&root, "clips/copy/a.mp4", &vid);
    let note = b"meeting notes\n".repeat(40);
    put(&root, "notes.txt", &note);
    put(&root, "notes (copy).txt", &note);
    let base = blob(3, 300 * 1024);
    let mut mid = base.clone();
    mid[150 * 1024] ^= 0xff;
    put(&root, "decoys/base.bin", &base);
    put(&root, "decoys/mid_differs.bin", &mid);
    put(&root, "unique/one.png", &blob(4, 50_000));
    put(&root, "empty.txt", b"");
    Fx {
        _tmp: tmp,
        root,
        journal,
    }
}

fn run(fx: &Fx, args: &[&str]) -> (i32, String, String) {
    let out = Command::new(bin())
        .args(args)
        .current_dir(&fx.root)
        .env("DEDUPE_JOURNAL_DIR", &fx.journal)
        .env("NO_COLOR", "1")
        .output()
        .expect("spawn dedupe");
    (
        out.status.code().unwrap_or(-1),
        String::from_utf8_lossy(&out.stdout).into_owned(),
        String::from_utf8_lossy(&out.stderr).into_owned(),
    )
}

fn files(root: &Path) -> Vec<String> {
    let mut v: Vec<String> = walkdir::WalkDir::new(root)
        .into_iter()
        .flatten()
        .filter(|e| e.file_type().is_file())
        .map(|e| {
            e.path()
                .strip_prefix(root)
                .unwrap()
                .to_string_lossy()
                .replace('\\', "/")
        })
        .collect();
    v.sort();
    v
}

#[test]
fn find_reports_groups_and_stages() {
    let fx = fixture();
    let (code, out, _) = run(&fx, &["find", "."]);
    assert_eq!(code, 0, "{out}");
    assert!(out.contains("3 groups   4 duplicates"), "{out}");
    assert!(out.contains("GROUP 001   2 copies   2.00 MB each"), "{out}");
    assert!(
        out.contains("keep  2019/trip/IMG_0041.jpg")
            || out.contains("keep  2019\\trip\\IMG_0041.jpg"),
        "{out}"
    );
    assert!(out.contains("9 share a size"), "{out}");
    assert!(out.contains("9 share a sample"), "{out}");
    assert!(out.contains("7 confirmed"), "{out}");
    assert!(
        !out.contains("mid_differs"),
        "sample-equal, content-different file must not be a duplicate\n{out}"
    );
    assert!(out.contains("next   dedupe milk . "), "{out}");
    // nothing written
    assert!(!fx.journal.exists());
    assert!(!fx.root.join("_milked").exists());
}

#[test]
fn find_top_level_only_without_dot() {
    let fx = fixture();
    let (code, out, _) = run(&fx, &["find"]);
    assert_eq!(code, 0);
    assert!(
        out.contains("1 group   1 duplicate   560 B reclaimable"),
        "{out}"
    );
}

#[test]
fn quick_search_reports_sample_tier() {
    let fx = fixture();
    let (code, out, _) = run(&fx, &["find", ".", "-q"]);
    assert_eq!(code, 0);
    assert!(out.contains("LIKELY 00"), "{out}");
    assert!(
        out.contains("mid_differs"),
        "quick search is sample-level by design\n{out}"
    );
    assert!(!out.contains("HASH "), "{out}");
}

#[test]
fn milk_then_undo_round_trip() {
    let fx = fixture();
    let before = files(&fx.root);

    let (code, out, _) = run(&fx, &["milk", ".", "--dry-run"]);
    assert_eq!(code, 0, "{out}");
    assert_eq!(files(&fx.root), before, "dry run must not touch the tree");
    assert!(!fx.journal.exists(), "dry run must not journal");

    let (code, out, _) = run(&fx, &["milk", "."]);
    assert_eq!(code, 0, "{out}");
    assert!(out.contains("4 moved"), "{out}");
    let after = files(&fx.root);
    assert!(
        after.contains(&"_milked/clips/copy/a.mp4".to_string()),
        "{after:?}"
    );
    assert!(
        after.contains(&"_milked/backup/old/IMG_0041 (1).jpg".to_string()),
        "{after:?}"
    );
    assert!(after.contains(&"2019/trip/IMG_0041.jpg".to_string()));
    assert!(!after.contains(&"backup/IMG_0041.jpg".to_string()));

    // idempotent
    let (code, out, _) = run(&fx, &["find", "."]);
    assert_eq!(code, 0);
    assert!(out.contains("no duplicates"), "{out}");

    let (code, out, _) = run(&fx, &["--undo"]);
    assert_eq!(code, 0, "{out}");
    assert!(out.contains("4 restored"), "{out}");
    assert_eq!(files(&fx.root), before, "undo must restore the exact tree");
    assert!(!fx.root.join("_milked").exists(), "empty _milked is pruned");

    let (code, out, _) = run(&fx, &["--undo"]);
    assert_eq!(code, 0);
    assert!(out.contains("nothing to undo"), "{out}");
}

#[test]
fn milk_collision_gets_suffix() {
    let fx = fixture();
    put(&fx.root, "_milked/notes (copy).txt", b"occupied");
    let (code, out, _) = run(&fx, &["milk"]);
    assert_eq!(code, 0, "{out}");
    assert!(
        fx.root.join("_milked/notes (copy) (2).txt").exists(),
        "{out}"
    );
    assert!(out.contains("as notes (copy) (2).txt"), "{out}");
}

#[test]
fn purge_dry_run_verifies_and_changes_nothing() {
    let fx = fixture();
    let before = files(&fx.root);
    let (code, out, _) = run(&fx, &["purge", ".", "-n"]);
    assert_eq!(code, 0, "{out}");
    assert!(out.contains("4 verified byte for byte"), "{out}");
    assert!(out.contains("4 would bin"), "{out}");
    assert_eq!(files(&fx.root), before);
    assert!(!fx.journal.exists());
}

#[test]
fn image_filter_only_sees_images() {
    let fx = fixture();
    let (code, out, _) = run(&fx, &["find", ".", "img"]);
    assert_eq!(code, 0);
    assert!(out.contains("1 group   2 duplicates"), "{out}");
    assert!(!out.contains("a.mp4"), "{out}");
}

#[test]
fn error_paths_exit_one_with_help_hint() {
    let fx = fixture();
    for args in [
        &["find", "--nope"][..],
        &["."],
        &["find", "a", "b"],
        &["find", "nowhere-xyz"],
    ] {
        let (code, _, err) = run(&fx, args);
        assert_eq!(code, 1, "{args:?}");
        assert!(err.contains("dedupe --help"), "{args:?}: {err}");
    }
}

#[test]
fn help_and_doctor() {
    let fx = fixture();
    let (code, out, _) = run(&fx, &["-h"]);
    assert_eq!(code, 0);
    assert!(
        out.contains("the deduplifier") && out.contains("--quick-search"),
        "{out}"
    );
    let (code, out, _) = run(&fx, &["-dr"]);
    assert!(code == 0 || code == 2, "{out}");
    assert!(out.contains("PASS  folder"), "{out}");
    assert!(out.contains("journal"), "{out}");
}

/// Touches the machine's Recycle Bin / trash. `cargo test -- --ignored`.
#[test]
#[ignore]
fn purge_then_undo_through_the_bin() {
    let fx = fixture();
    let before = files(&fx.root);
    let (code, out, _) = run(&fx, &["purge", "."]);
    assert_eq!(code, 0, "{out}");
    assert!(out.contains("4 binned"), "{out}");
    assert!(!fx.root.join("backup/IMG_0041.jpg").exists());
    let (code, out, _) = run(&fx, &["--undo"]);
    assert_eq!(code, 0, "{out}");
    assert!(out.contains("4 restored"), "{out}");
    assert_eq!(files(&fx.root), before);
    let a = fs::read(fx.root.join("2019/trip/IMG_0041.jpg")).unwrap();
    let b = fs::read(fx.root.join("backup/IMG_0041.jpg")).unwrap();
    assert_eq!(a, b);
}
