//! The commands: find, milk, purge, undo. Each one runs the shared
//! scan → group → order pipeline, then acts, then journals.

use std::fs;
use std::path::{Path, PathBuf};
use std::time::{Instant, SystemTime};

use rayon::prelude::*;

use crate::cli::{Command, Invocation};
use crate::exact::{self, Group, PipelineStats, Progress, Stage};
use crate::journal::{self, Entry, Journal, Op};
use crate::keeper;
use crate::render::{LiveProgress, Renderer};
use crate::theme::Role;
use crate::util::{fmt_count, rel_display, unix_secs};
use crate::walk::{self, ScanStats};
use crate::MILKED_DIR;

pub const EXIT_OK: i32 = 0;
pub const EXIT_USER: i32 = 1;
pub const EXIT_FAILED: i32 = 2;

/// Dispatch. Returns the process exit code.
pub fn run(inv: &Invocation, r: &Renderer) -> i32 {
    match inv.command {
        Command::Find => find(inv, r),
        Command::Milk => milk(inv, r),
        Command::Purge => purge(inv, r),
        Command::Undo => undo(inv, r),
        Command::Doctor | Command::Help | Command::Menu => EXIT_OK,
    }
}

struct Found {
    groups: Vec<Group>,
    scan: ScanStats,
    pipe: PipelineStats,
}

fn scan_and_group(inv: &Invocation, r: &Renderer) -> Found {
    let lp = LiveProgress::new(r.theme);
    let t0 = Instant::now();
    lp.begin(Stage::Scan);
    let (cands, scan) = walk::scan(&inv.root, inv.recurse, inv.kind, &mut |s| {
        lp.update_text(Stage::Scan, s.files, r.scan_text(s, None));
    });
    lp.finish(Stage::Scan, r.scan_text(&scan, Some(t0.elapsed())));

    let (mut groups, pipe) = exact::find_groups(cands, inv.quick, &lp);
    keeper::order(&mut groups);
    Found { groups, scan, pipe }
}

// ---------------------------------------------------------------------------

fn find(inv: &Invocation, r: &Renderer) -> i32 {
    r.header(inv);
    let f = scan_and_group(inv, r);
    r.groups(&f.groups, &inv.root);
    r.skipped(&f.scan, &f.pipe);
    r.totals(&f.groups, &f.scan);
    if !f.groups.is_empty() {
        r.next_after_find(inv);
    }
    EXIT_OK
}

// ---------------------------------------------------------------------------

/// `dst` with ` (2)`, ` (3)` … inserted before the extension until free.
fn unique_path(dst: &Path) -> PathBuf {
    if !dst.exists() {
        return dst.to_path_buf();
    }
    let stem = dst
        .file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_default();
    let ext = dst.extension().map(|e| format!(".{}", e.to_string_lossy()));
    let parent = dst.parent().map(Path::to_path_buf).unwrap_or_default();
    let mut n = 2;
    loop {
        let name = format!("{stem} ({n}){}", ext.clone().unwrap_or_default());
        let p = parent.join(name);
        if !p.exists() {
            return p;
        }
        n += 1;
    }
}

fn milk(inv: &Invocation, r: &Renderer) -> i32 {
    r.header(inv);
    let f = scan_and_group(inv, r);
    r.groups(&f.groups, &inv.root);
    r.skipped(&f.scan, &f.pipe);
    r.totals(&f.groups, &f.scan);
    if f.groups.is_empty() {
        return EXIT_OK;
    }
    r.blank();

    let milked = inv.root.join(MILKED_DIR);
    let mut j = Journal::new(&inv.root, &inv.command_line());
    let mut moved: u64 = 0;
    let mut bytes: u64 = 0;
    let mut failed: u64 = 0;

    for g in &f.groups {
        for m in &g.members[1..] {
            let rel = rel_display(&m.path, &inv.root);
            let rel_path = m
                .path
                .strip_prefix(&inv.root)
                .map(Path::to_path_buf)
                .unwrap_or_else(|_| PathBuf::from(m.path.file_name().unwrap_or_default()));
            let planned = milked.join(&rel_path);
            let dst = unique_path(&planned);
            // the destination mirrors the source path under _milked; only a
            // renamed collision is worth a word on the line
            let dst_rel = if dst == planned {
                String::new()
            } else {
                format!(
                    "as {}",
                    dst.file_name()
                        .map(|n| n.to_string_lossy().into_owned())
                        .unwrap_or_default()
                )
            };
            if inv.dry_run {
                r.action("would", Role::Warn, &rel, &dst_rel);
                moved += 1;
                bytes += m.size;
                continue;
            }
            let res = dst
                .parent()
                .map(fs::create_dir_all)
                .unwrap_or(Ok(()))
                .and_then(|_| fs::rename(&m.path, &dst));
            match res {
                Ok(()) => {
                    r.action("moved", Role::Ok, &rel, &dst_rel);
                    moved += 1;
                    bytes += m.size;
                    j.entries.push(Entry {
                        op: Op::Move {
                            from: m.path.clone(),
                            to: dst.clone(),
                        },
                        size: m.size,
                        hash: exact::hex(&g.hash),
                    });
                }
                Err(e) => {
                    r.action("failed", Role::Danger, &rel, &os_err(&e));
                    failed += 1;
                }
            }
        }
    }

    let journal_id = if inv.dry_run || j.entries.is_empty() {
        None
    } else {
        match journal::write(&mut j) {
            Ok(_) => Some(j.id.clone()),
            Err(e) => {
                r.note(
                    Role::Danger,
                    &format!("journal not written: {e}   (moves done; undo unavailable)"),
                );
                None
            }
        }
    };

    let verb = if inv.dry_run { "would move" } else { "moved" };
    r.action_totals(
        verb,
        moved,
        bytes,
        &format!("into {}", milked.to_string_lossy()),
        journal_id.as_deref(),
    );
    if failed > 0 {
        r.note(
            Role::Danger,
            &format!(
                "{} could not be moved and stay where they are",
                fmt_count(failed)
            ),
        );
    }
    if journal_id.is_some() {
        r.undo_hint(inv);
    }
    if failed > 0 {
        EXIT_FAILED
    } else {
        EXIT_OK
    }
}

// ---------------------------------------------------------------------------

fn purge(inv: &Invocation, r: &Renderer) -> i32 {
    r.header(inv);
    let f = scan_and_group(inv, r);

    // VERIFY — byte-for-byte against the keeper, parallel across files
    let lp = LiveProgress::new(r.theme);
    let pairs: Vec<(usize, usize)> = f
        .groups
        .iter()
        .enumerate()
        .flat_map(|(gi, g)| (1..g.members.len()).map(move |mi| (gi, mi)))
        .collect();
    let total = pairs.len() as u64;
    let mut verified: Vec<Vec<bool>> = f
        .groups
        .iter()
        .map(|g| vec![false; g.members.len()])
        .collect();
    if total > 0 && !inv.quick {
        lp.tick(Stage::Verify, 0, total);
        let counter = std::sync::atomic::AtomicU64::new(0);
        let results: Vec<((usize, usize), bool)> = pairs
            .par_iter()
            .map(|&(gi, mi)| {
                let g = &f.groups[gi];
                let ok = exact::verify_identical(&g.members[0].path, &g.members[mi].path)
                    .unwrap_or(false);
                let d = counter.fetch_add(1, std::sync::atomic::Ordering::Relaxed) + 1;
                lp.tick(Stage::Verify, d, total);
                ((gi, mi), ok)
            })
            .collect();
        let mut ok_n = 0u64;
        for ((gi, mi), ok) in results {
            verified[gi][mi] = ok;
            if ok {
                ok_n += 1;
            }
        }
        let mut p = f.pipe;
        p.confirmed = ok_n;
        lp.done(Stage::Verify, &p);
    } else if total > 0 {
        // quick search: sample-level matches, explicitly requested; no byte verify is possible
        for v in verified.iter_mut() {
            for x in v.iter_mut().skip(1) {
                *x = true;
            }
        }
    }

    r.groups(&f.groups, &inv.root);
    r.skipped(&f.scan, &f.pipe);
    r.totals(&f.groups, &f.scan);
    if f.groups.is_empty() {
        return EXIT_OK;
    }
    r.blank();

    // collect what passed verification
    let mut to_bin: Vec<(usize, usize)> = Vec::new();
    let mut kept_mismatch: u64 = 0;
    for (gi, g) in f.groups.iter().enumerate() {
        for (mi, ok) in verified[gi].iter().enumerate().skip(1) {
            if *ok {
                to_bin.push((gi, mi));
            } else {
                kept_mismatch += 1;
                r.action(
                    "kept",
                    Role::Warn,
                    &rel_display(&g.members[mi].path, &inv.root),
                    "bytes differ from keeper",
                );
            }
        }
    }

    let mut j = Journal::new(&inv.root, &inv.command_line());
    let mut binned: u64 = 0;
    let mut bytes: u64 = 0;
    let mut failed: u64 = 0;

    if inv.dry_run {
        for &(gi, mi) in &to_bin {
            let m = &f.groups[gi].members[mi];
            r.action(
                "would",
                Role::Warn,
                &rel_display(&m.path, &inv.root),
                "Recycle Bin",
            );
            binned += 1;
            bytes += m.size;
        }
    } else {
        // batched bin calls (one shell operation per chunk on Windows), then
        // confirm per file by checking it is gone
        for chunk in to_bin.chunks(500) {
            let paths: Vec<&Path> = chunk
                .iter()
                .map(|&(gi, mi)| f.groups[gi].members[mi].path.as_path())
                .collect();
            let t = unix_secs(SystemTime::now());
            let res = trash::delete_all(&paths);
            for &(gi, mi) in chunk {
                let g = &f.groups[gi];
                let m = &g.members[mi];
                let rel = rel_display(&m.path, &inv.root);
                if !m.path.exists() {
                    r.action("binned", Role::Ok, &rel, "");
                    binned += 1;
                    bytes += m.size;
                    j.entries.push(Entry {
                        op: Op::Trash {
                            path: m.path.clone(),
                            time_deleted: t,
                        },
                        size: m.size,
                        hash: exact::hex(&g.hash),
                    });
                } else {
                    let why = match &res {
                        Err(e) => e.to_string(),
                        Ok(()) => "still present".to_string(),
                    };
                    r.action("failed", Role::Danger, &rel, &why);
                    failed += 1;
                }
            }
        }
    }

    let journal_id = if inv.dry_run || j.entries.is_empty() {
        None
    } else {
        match journal::write(&mut j) {
            Ok(_) => Some(j.id.clone()),
            Err(e) => {
                r.note(Role::Danger, &format!("journal not written: {e}   (files are in the Recycle Bin; dedupe --undo unavailable)"));
                None
            }
        }
    };

    let verb = if inv.dry_run { "would bin" } else { "binned" };
    r.action_totals(
        verb,
        binned,
        bytes,
        "to the Recycle Bin",
        journal_id.as_deref(),
    );
    if kept_mismatch > 0 {
        r.note(
            Role::Warn,
            &format!(
                "{} kept: bytes differed from the keeper at verify time",
                fmt_count(kept_mismatch)
            ),
        );
    }
    if failed > 0 {
        r.note(
            Role::Danger,
            &format!(
                "{} could not be binned and stay where they are",
                fmt_count(failed)
            ),
        );
    }
    if journal_id.is_some() {
        r.undo_hint(inv);
    }
    if failed > 0 {
        EXIT_FAILED
    } else {
        EXIT_OK
    }
}

// ---------------------------------------------------------------------------

fn undo(inv: &Invocation, r: &Renderer) -> i32 {
    r.header(inv);
    let (jpath, mut j) = match journal::latest_pending(&inv.root) {
        Ok(Some(x)) => x,
        Ok(None) => {
            r.note(
                Role::Dupe,
                &format!("nothing to undo under {}", inv.root.to_string_lossy()),
            );
            return EXIT_OK;
        }
        Err(e) => {
            r.error(&format!("journal unreadable  {e}"));
            return EXIT_FAILED;
        }
    };
    r.note(
        Role::Plate,
        &format!(
            "journal {}   {}   {} entries",
            j.id,
            j.command,
            fmt_count(j.entries.len() as u64)
        ),
    );
    r.blank();

    let mut restored: u64 = 0;
    let mut bytes: u64 = 0;
    let mut failed: u64 = 0;

    // moves, newest first
    for e in j.entries.iter().rev() {
        if let Op::Move { from, to } = &e.op {
            let rel = rel_display(from, &inv.root);
            if inv.dry_run {
                r.action("would", Role::Warn, &rel, "restore");
                restored += 1;
                bytes += e.size;
                continue;
            }
            if !to.exists() {
                r.action(
                    "missing",
                    Role::Danger,
                    &rel_display(to, &inv.root),
                    "not in _milked any more",
                );
                failed += 1;
                continue;
            }
            if from.exists() {
                r.action("exists", Role::Warn, &rel, "left in _milked");
                failed += 1;
                continue;
            }
            let res = from
                .parent()
                .map(fs::create_dir_all)
                .unwrap_or(Ok(()))
                .and_then(|_| fs::rename(to, from));
            match res {
                Ok(()) => {
                    r.action("restored", Role::Ok, &rel, "");
                    restored += 1;
                    bytes += e.size;
                }
                Err(err) => {
                    r.action("failed", Role::Danger, &rel, &os_err(&err));
                    failed += 1;
                }
            }
        }
    }

    // bin restores, one listing of the bin for all of them
    let binned: Vec<(&PathBuf, i64, u64)> = j
        .entries
        .iter()
        .filter_map(|e| match &e.op {
            Op::Trash { path, time_deleted } => Some((path, *time_deleted, e.size)),
            _ => None,
        })
        .collect();
    if !binned.is_empty() {
        if inv.dry_run {
            for (p, _, sz) in &binned {
                r.action(
                    "would",
                    Role::Warn,
                    &rel_display(p, &inv.root),
                    "restore from Recycle Bin",
                );
                restored += 1;
                bytes += sz;
            }
        } else {
            for (p, ok, why, sz) in restore_from_bin(&binned) {
                let rel = rel_display(&p, &inv.root);
                if ok {
                    r.action("restored", Role::Ok, &rel, "from Recycle Bin");
                    restored += 1;
                    bytes += sz;
                } else {
                    r.action("failed", Role::Danger, &rel, &why);
                    failed += 1;
                }
            }
        }
    }

    if !inv.dry_run {
        if let Err(e) = journal::mark_consumed(&jpath, &mut j) {
            r.note(
                Role::Danger,
                &format!("journal could not be marked undone: {e}"),
            );
        }
        prune_empty_dirs(&inv.root.join(MILKED_DIR));
    }

    let verb = if inv.dry_run {
        "would restore"
    } else {
        "restored"
    };
    r.action_totals(verb, restored, bytes, "back in place", Some(&j.id));
    if failed > 0 {
        r.note(
            Role::Danger,
            &format!("{} could not be restored", fmt_count(failed)),
        );
    }
    if failed > 0 {
        EXIT_FAILED
    } else {
        EXIT_OK
    }
}

/// Restore journaled bin entries. Returns (path, ok, reason, size) per entry.
#[cfg(any(windows, all(unix, not(target_os = "macos"))))]
fn restore_from_bin(entries: &[(&PathBuf, i64, u64)]) -> Vec<(PathBuf, bool, String, u64)> {
    use trash::os_limited;
    let mut out = Vec::new();
    let items = match os_limited::list() {
        Ok(v) => v,
        Err(e) => {
            return entries
                .iter()
                .map(|(p, _, sz)| ((*p).clone(), false, format!("bin unreadable: {e}"), *sz))
                .collect();
        }
    };
    let mut to_restore = Vec::new();
    let mut idx_of: Vec<Option<usize>> = Vec::new();
    for (p, t, _) in entries {
        let found = items.iter().position(|it| {
            let orig = it.original_parent.join(&it.name);
            &orig == *p && it.time_deleted >= *t - 2
        });
        idx_of.push(found);
        if let Some(i) = found {
            to_restore.push(items[i].clone());
        }
    }
    let restore_result = if to_restore.is_empty() {
        Ok(())
    } else {
        os_limited::restore_all(to_restore)
    };
    for (k, (p, _, sz)) in entries.iter().enumerate() {
        match idx_of[k] {
            None => out.push((
                (*p).clone(),
                false,
                "not in the Recycle Bin".to_string(),
                *sz,
            )),
            Some(_) => match &restore_result {
                Ok(()) => out.push((
                    (*p).clone(),
                    p.exists(),
                    if p.exists() {
                        String::new()
                    } else {
                        "restore reported ok but file absent".into()
                    },
                    *sz,
                )),
                Err(e) => out.push(((*p).clone(), p.exists(), e.to_string(), *sz)),
            },
        }
    }
    out
}

#[cfg(not(any(windows, all(unix, not(target_os = "macos")))))]
fn restore_from_bin(entries: &[(&PathBuf, i64, u64)]) -> Vec<(PathBuf, bool, String, u64)> {
    entries
        .iter()
        .map(|(p, _, sz)| {
            (
                (*p).clone(),
                false,
                "restoring from the bin is not supported on this OS; use Finder".to_string(),
                *sz,
            )
        })
        .collect()
}

/// Remove empty directories bottom-up under `dir`, including `dir` itself.
fn prune_empty_dirs(dir: &Path) {
    if !dir.is_dir() {
        return;
    }
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() {
            if e.file_type().map(|t| t.is_dir()).unwrap_or(false) {
                prune_empty_dirs(&e.path());
            }
        }
    }
    let _ = fs::remove_dir(dir); // fails harmlessly when not empty
}

pub fn os_err(e: &std::io::Error) -> String {
    let s = e.to_string();
    // strip the "(os error N)" suffix std appends
    match s.find(" (os error") {
        Some(i) => s[..i].to_string(),
        None => s,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unique_path_suffixes() {
        let d = tempfile::tempdir().unwrap();
        let p = d.path().join("x.jpg");
        assert_eq!(unique_path(&p), p);
        fs::write(&p, b"1").unwrap();
        assert_eq!(unique_path(&p), d.path().join("x (2).jpg"));
        fs::write(d.path().join("x (2).jpg"), b"1").unwrap();
        assert_eq!(unique_path(&p), d.path().join("x (3).jpg"));
        let noext = d.path().join("noext");
        fs::write(&noext, b"1").unwrap();
        assert_eq!(unique_path(&noext), d.path().join("noext (2)"));
    }

    #[test]
    fn prune_removes_only_empty() {
        let d = tempfile::tempdir().unwrap();
        let m = d.path().join("_milked");
        fs::create_dir_all(m.join("a/b")).unwrap();
        fs::create_dir_all(m.join("c")).unwrap();
        fs::write(m.join("c/keep.txt"), b"x").unwrap();
        prune_empty_dirs(&m);
        assert!(!m.join("a").exists());
        assert!(m.join("c/keep.txt").exists());
        assert!(m.exists());
    }
}
