# PLAN — one thread, modulated phases

Language: **Rust**. Reasons, in the open: single static binary on Windows
with no runtime to install; BLAKE3 and rayon give multi-core hashing at I/O
speed; crossterm gives raw-mode menus and Windows virtual-terminal colour
without a widget framework. Python with `rich` was the alternative; it loses
on cold-start time for "fast and punchy" commands and on hashing throughput
for large trees. Effort was not a factor either way — both were built from
scratch here.

Every phase ends with the agent running the binary in its own runtime on a
generated fixture tree and recording what it observed. Nothing is marked
done on the strength of compiling.

## Phase 1 — exact duplicates, full command surface   ← this delivery

- Grammar and pre-parser (`-dr`, `.` as all, order-independent tokens)
- Walker with kind filters, hard-link collapse, `_milked` exclusion
- Size → sample → BLAKE3 pipeline, parallel hashing
- Keeper policy
- `find`, `milk`, `purge` (exact tier + byte verification + Recycle Bin),
  `--dry-run`, `--quick-search`, `--undo`, `doctor`, `--help`
- Journal (write on change only; undo for moves and bin restores)
- Renderer: theme, width fitting, in-place progress, result layouts
- Interactive menu: five workflows, four steps, confirm-with-command
- Tests: grammar, size/sample/hash staging, keeper ordering, journal
  round-trip, path shortening; end-to-end runs on a fixture tree

Known gaps at the end of Phase 1, stated plainly in the delivery note.

## Phase 2 — near-duplicate images

- Image decode (`image` crate), dHash and pHash implemented from the
  mathematics in RESEARCH §2, with the mirror hash
- Linear scan ≤ 20k images, Multi-Index Hashing above
- Union–find grouping; `img` token switches the pipeline on; `purge`
  requires both hashes to agree
- Verification corpus: generated images × {resize, JPEG q, crop, rotate,
  mirror, brightness, watermark}; measured false-positive and
  false-negative rates fix the shipped thresholds
- Phase 2b: PDQ with quality gating as the `purge` tier

## Phase 3 — near-duplicate video

- `ffmpeg`/`ffprobe` subprocess probing and positional frame extraction
- Tier 1 positional frame hashing; tier 2 TMK-style descriptor
- `vid` token switches it on; `doctor` reports the ffmpeg state

## Phase 4 — optional deep tier

- SSCD-class descriptor behind an opt-in flag, off by default; separate
  model download; never required for the core commands

## Standing rules

- No cache, index or lock file is ever written on a scan.
- A change writes exactly one journal; `--undo` consumes it.
- Thresholds ship only after they are measured on a corpus in the phase
  that introduces them.
- New flags need a reason stronger than convenience; the menu stays at five
  choices per screen.
